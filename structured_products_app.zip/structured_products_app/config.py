"""
config.py — Shared styles, constants, and color palette for the app.
"""

# ── Color Palette ──────────────────────────────────────────────
DARK_BG = "#0E1117"
CARD_BG = "#1B2A4A"
ACCENT_GOLD = "#D4A843"
ACCENT_BLUE = "#5DADE2"
ACCENT_GREEN = "#2ECC71"
ACCENT_RED = "#E74C3C"
TEXT_WHITE = "#FFFFFF"
TEXT_GREY = "#8899AA"

# ── Plotly Chart Template ──────────────────────────────────────
PLOTLY_LAYOUT = dict(
    template="plotly_dark",
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(14,17,23,0.8)",
    font=dict(family="Arial", color=TEXT_WHITE, size=12),
    margin=dict(l=60, r=30, t=50, b=50),
    legend=dict(bgcolor="rgba(0,0,0,0.3)", bordercolor=TEXT_GREY, borderwidth=1),
)

# ── Available Instruments ──────────────────────────────────────
INSTRUMENTS = [
    "None", "Call", "Put", "Forward",
    "Digital Call", "Digital Put",
    "Barrier KI Call", "Barrier KI Put",
    "Barrier KO Call", "Barrier KO Put",
    "One-Touch Up", "No-Touch Up",
    "One-Touch Down", "No-Touch Down",
    "Gap Call", "Range Accrual",
    "Autocall Coupon", "Capital Protected",
    "Reverse Convertible", "Straddle",
]

DIRECTIONS = ["Long", "Short"]

# ── Strategy Presets ───────────────────────────────────────────
# Each preset: dict of leg_index -> (instrument, direction, K, barrier, T, premium, qty)
STRATEGY_PRESETS = {
    "── Select a preset ──": {},
    "Bull Call Spread": {
        0: ("Call", "Long", 100, 0, 1, 3.0, 1),
        1: ("Call", "Short", 110, 0, 1, 1.5, 1),
    },
    "Bear Put Spread": {
        0: ("Put", "Long", 100, 0, 1, 3.5, 1),
        1: ("Put", "Short", 90, 0, 1, 1.5, 1),
    },
    "Long Straddle": {
        0: ("Call", "Long", 100, 0, 1, 5.0, 1),
        1: ("Put", "Long", 100, 0, 1, 5.0, 1),
    },
    "Long Strangle": {
        0: ("Call", "Long", 110, 0, 1, 2.0, 1),
        1: ("Put", "Long", 90, 0, 1, 2.0, 1),
    },
    "Butterfly (Call)": {
        0: ("Call", "Long", 90, 0, 1, 7.0, 1),
        1: ("Call", "Short", 100, 0, 1, 4.0, 2),
        2: ("Call", "Long", 110, 0, 1, 2.0, 1),
    },
    "Iron Condor": {
        0: ("Put", "Long", 80, 0, 1, 0.5, 1),
        1: ("Put", "Short", 90, 0, 1, 2.0, 1),
        2: ("Call", "Short", 110, 0, 1, 2.0, 1),
        3: ("Call", "Long", 120, 0, 1, 0.5, 1),
    },
    "Collar": {
        0: ("Forward", "Long", 100, 0, 1, 0, 1),
        1: ("Put", "Long", 90, 0, 1, 2.0, 1),
        2: ("Call", "Short", 110, 0, 1, 2.0, 1),
    },
    "Risk Reversal": {
        0: ("Call", "Long", 110, 0, 1, 2.0, 1),
        1: ("Put", "Short", 90, 0, 1, 2.0, 1),
    },
    "Protective Put": {
        0: ("Forward", "Long", 100, 0, 1, 0, 1),
        1: ("Put", "Long", 95, 0, 1, 3.0, 1),
    },
    "Covered Call": {
        0: ("Forward", "Long", 100, 0, 1, 0, 1),
        1: ("Call", "Short", 110, 0, 1, 3.0, 1),
    },
    "Call Ratio Spread 1×2": {
        0: ("Call", "Long", 100, 0, 1, 5.0, 1),
        1: ("Call", "Short", 110, 0, 1, 2.5, 2),
    },
    "Jade Lizard": {
        0: ("Put", "Short", 90, 0, 1, 2.0, 1),
        1: ("Call", "Short", 110, 0, 1, 2.0, 1),
        2: ("Call", "Long", 120, 0, 1, 0.5, 1),
    },
    "Digital Bet (Up)": {
        0: ("Digital Call", "Long", 105, 10, 1, 4.0, 1),
    },
    "Knock-In Call": {
        0: ("Barrier KI Call", "Long", 100, 110, 1, 3.0, 1),
    },
}

# ── Swap Types ─────────────────────────────────────────────────
SWAP_TYPES = ["IRS Pay Fixed", "IRS Receive Fixed", "Basis Swap", "XCCY Swap"]
DAY_COUNTS = ["30/360", "ACT/360", "ACT/365"]
