"""
exotic_pricer.py — Exotic Options Pricer with 15 closed-form options + Greeks.
"""

import streamlit as st
import numpy as np
import plotly.graph_objects as go
import pandas as pd
from config import (PLOTLY_LAYOUT, ACCENT_GOLD, ACCENT_BLUE, ACCENT_GREEN,
                    ACCENT_RED, TEXT_GREY)
from models.exotic_options import price_all_exotics
from models.black_scholes import call_price, put_price, call_greeks, put_greeks


def render():
    st.markdown("## 🧮 Exotic Options Pricer — Black-Scholes & Closed-Form")
    st.caption("European · Digital · No-Touch · One-Touch · Double No-Touch · Asian · "
               "Lookback · Chooser · Gap · Power · Range Accrual")

    # ── Copy Zone ──
    with st.expander("🔗 Import from Structured Products", expanded=False):
        st.info("Toggle ON to auto-fill S₀ and σ from the Structured Products tab inputs "
                "(stored in session state).")
        use_copy = st.toggle("Use Structured Products inputs", value=False, key="ex_copy")
        if use_copy and "sp_S0" in st.session_state:
            st.success(f"Imported: S₀ = {st.session_state.get('sp_S0', 100)}")

    # ── Market Parameters ──
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("#### Market Parameters")
        default_S = st.session_state.get("sp_S0", 100.0) if st.session_state.get("ex_copy") else 100.0
        S = st.number_input("Spot Price S₀", value=default_S, step=1.0, key="ex_S")
        K = st.number_input("Strike K", value=100.0, step=1.0, key="ex_K")
        T = st.number_input("Maturity T (yr)", value=1.0, step=0.25, key="ex_T")
        r = st.number_input("Risk-Free Rate r", value=0.05, step=0.005, format="%.3f", key="ex_r")
        sigma = st.number_input("Volatility σ", value=0.20, step=0.01, format="%.2f", key="ex_sig")
        q = st.number_input("Dividend Yield q", value=0.02, step=0.005, format="%.3f", key="ex_q")

    with col2:
        st.markdown("#### Exotic Parameters")
        H_up = st.number_input("Upper Barrier H", value=120.0, step=5.0, key="ex_H")
        H_down = st.number_input("Lower Barrier L", value=80.0, step=5.0, key="ex_L")
        Q_pay = st.number_input("Digital Payout Q", value=1.0, step=0.1, key="ex_Q")
        sig2 = st.number_input("2nd Asset Vol σ₂", value=0.25, step=0.01, format="%.2f", key="ex_sig2")
        rho = st.number_input("Correlation ρ", value=0.50, step=0.1, format="%.2f", key="ex_rho")
        n_pow = st.number_input("Power n", value=2, step=1, key="ex_npow")
        t_c = st.number_input("Chooser Time t_c", value=0.5, step=0.1, format="%.2f", key="ex_tc")
        K_gap = st.number_input("Gap Strike K_gap", value=105.0, step=1.0, key="ex_Kgap")

    st.markdown("---")

    # ── Price All 15 Exotics ──
    results = price_all_exotics(
        S, K, T, r, sigma, q, H_up, H_down, Q_pay,
        sig2, rho, 95, n_pow, t_c, K_gap,
    )

    st.markdown("#### 15 Exotic Options — Prices & Greeks")

    # Build display table
    rows = []
    for i, res in enumerate(results):
        row = {
            "#": i + 1,
            "Option": res["name"],
            "Method": res["method"],
            "Price": f"{res['price']:.4f}",
        }
        for g in ["delta", "gamma", "vega", "theta", "rho"]:
            val = res.get(g)
            row[g.capitalize()] = f"{val:.6f}" if val is not None else "MC"
        rows.append(row)

    df = pd.DataFrame(rows)
    st.dataframe(df, use_container_width=True, hide_index=True, height=580)

    # ── Greeks Surface ──
    st.markdown("---")
    st.markdown("#### 📊 Greeks Visualization")

    greek_choice = st.selectbox("Select Greek to plot", ["Delta", "Gamma", "Vega", "Theta"],
                                key="ex_greek")
    opt_type = st.radio("Option type", ["Call", "Put"], horizontal=True, key="ex_opttype")

    S_range = np.linspace(max(S * 0.5, 1), S * 1.5, 80)
    sig_range = np.linspace(0.05, 0.60, 50)

    greek_key = greek_choice.lower()
    greek_fn = call_greeks if opt_type == "Call" else put_greeks

    Z = np.zeros((len(sig_range), len(S_range)))
    for i, sv in enumerate(sig_range):
        for j, spot in enumerate(S_range):
            try:
                g = greek_fn(spot, K, T, r, sv, q)
                Z[i, j] = g[greek_key]
            except Exception:
                Z[i, j] = 0

    fig = go.Figure(data=[go.Surface(
        x=S_range, y=sig_range, z=Z,
        colorscale="Viridis", opacity=0.9,
    )])
    fig.update_layout(
        title=f"{greek_choice} Surface — {opt_type} (K={K})",
        scene=dict(
            xaxis_title="Spot Price S",
            yaxis_title="Volatility σ",
            zaxis_title=greek_choice,
            bgcolor="rgba(14,17,23,0.8)",
        ),
        **{k: v for k, v in PLOTLY_LAYOUT.items() if k != "template"},
        template="plotly_dark",
        height=550,
    )
    st.plotly_chart(fig, use_container_width=True)

    # ── Formulas Reference ──
    with st.expander("📐 Formulas Reference"):
        formulas = [
            ("European Call", "C = S·e⁻qᵀ·N(d₁) − K·e⁻ʳᵀ·N(d₂)"),
            ("European Put", "P = K·e⁻ʳᵀ·N(−d₂) − S·e⁻qᵀ·N(−d₁)"),
            ("d₁, d₂", "d₁ = [ln(S/K) + (r−q+σ²/2)T] / (σ√T),  d₂ = d₁ − σ√T"),
            ("Digital Call", "DC = Q·e⁻ʳᵀ·N(d₂)"),
            ("Digital Put", "DP = Q·e⁻ʳᵀ·N(−d₂)"),
            ("One-Touch Up", "OT↑ = e⁻ʳᵀ·[N((μT−b)/(σ√T)) + e^(2μb/σ²)·N((−μT−b)/(σ√T))]"),
            ("No-Touch", "NT = e⁻ʳᵀ − OT"),
            ("Asian (Geom.)", "Kemna-Vorst: σ̂=σ/√3, b̂=½(r−q−σ²/6), then BSM(S,K,T,r,σ̂,b̂)"),
            ("Lookback", "Goldman-Sosin-Gatto closed-form with running min"),
            ("Chooser", "Rubinstein: C(S,K,T) + K·e⁻ʳᵀ·N(−d₂(tc)) − S·e⁻qᵀ·N(−d₁(tc))"),
            ("Gap Call", "GC = S·e⁻qᵀ·N(d₁(K_gap)) − K·e⁻ʳᵀ·N(d₂(K_gap))"),
            ("Power", "e⁻ʳᵀ · Sⁿ · exp[n(r−q)T + n(n−1)σ²T/2]"),
            ("Range Accrual", "P(L < S_T < H) · e⁻ʳᵀ via log-normal CDF"),
        ]
        for name, formula in formulas:
            st.markdown(f"**{name}**: `{formula}`")
