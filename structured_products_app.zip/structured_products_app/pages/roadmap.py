"""
roadmap.py — Roadmap & Next Steps page.
"""

import streamlit as st
import pandas as pd


def render():
    st.markdown("## 🗺️ Roadmap & Next Steps")
    st.caption("18 Prioritized Improvements · Mathematical Corrections · Architecture Notes")

    # ── Priority Improvements ──
    st.markdown("#### 🎯 Prioritized Improvements")

    roadmap = [
        ("P0", "Greeks Surface 3D", "Delta/Gamma/Vega vs S and σ for P&L visualization", "✅ Done"),
        ("P0", "Implied Volatility Solver", "Newton-Raphson for market calibration", "✅ Done"),
        ("P1", "Volatility Smile / Skew", "SABR, SVI, or spline interpolation", "🔲 Planned"),
        ("P1", "Yield Curve Bootstrapping", "Zero-coupon from swaps/bonds", "🔲 Planned"),
        ("P1", "Variance Reduction MC", "Antithetic variates, control variates, importance sampling — 50-70% error reduction", "🔲 Planned"),
        ("P1", "P&L Attribution", "Delta P&L + Gamma P&L + Vega P&L + Theta P&L + residual", "🔲 Planned"),
        ("P1", "VaR / CVaR", "Parametric + historical 99%/95% + Expected Shortfall", "🔲 Planned"),
        ("P1", "Greeks MC (Pathwise)", "IPA + likelihood ratio for exotics without closed-form Greeks", "🔲 Planned"),
        ("P2", "Multi-Asset Correlation", "Cholesky decomposition for worst-of, best-of, rainbow", "🔲 Planned"),
        ("P2", "Heston Stochastic Vol", "FFT Carr-Madan calibration", "🔲 Planned"),
        ("P2", "Local Vol (Dupire)", "σ_loc(K,T) surface for path-dependent pricing", "🔲 Planned"),
        ("P2", "XVA Sensitivities", "CVA, DVA, FVA, KVA for counterparty risk", "🔲 Planned"),
        ("P2", "Swaption Pricer", "Black76, Bachelier, vol cube", "🔲 Planned"),
        ("P2", "Live Data Feed", "Bloomberg B-PIPE, Yahoo Finance, Refinitiv API", "🔲 Planned"),
        ("P2", "Binomial/Trinomial Trees", "CRR for American options, early exercise boundary", "🔲 Planned"),
        ("P2", "Jump-Diffusion (Merton)", "Poisson jumps + lognormal for fat tails", "🔲 Planned"),
        ("P3", "Backtesting", "Delta-hedging P&L, gamma scalping simulation", "🔲 Planned"),
        ("P3", "PDF Report Generator", "Automated export with charts and commentary", "🔲 Planned"),
    ]

    df = pd.DataFrame(roadmap, columns=["Priority", "Feature", "Description", "Status"])

    # Color-code by priority
    def color_priority(val):
        colors = {"P0": "background-color: #1a472a; color: #2ECC71",
                  "P1": "background-color: #2d3a1a; color: #D4A843",
                  "P2": "background-color: #2a2a3a; color: #5DADE2",
                  "P3": "background-color: #2a1a1a; color: #E74C3C"}
        return [colors.get(val[0], "") for _ in val]

    st.dataframe(df, use_container_width=True, hide_index=True, height=680)

    # ── Mathematical Corrections ──
    st.markdown("---")
    st.markdown("#### 📐 Mathematical Corrections Applied (v5)")

    corrections = [
        "BSM with continuous dividends (q) in **all** formulas",
        "One-Touch exact formula with **reflection principle** (not λ approximation)",
        "Asian geometric: **Kemna-Vorst** with σ̂ = σ/√3, b̂ = ½(r−q−σ²/6)",
        "Monte Carlo: **log-Euler scheme** for exact GBM discretization",
        "Greeks: all calculated with **closed-form BSM** including dividend yield q",
        "Range Accrual: **lognormal CDF** of ln(S_T) ~ N(μT, σ²T)",
        "Digital Greeks: complete **Delta, Gamma, Vega, Theta, Rho**",
        "One-Touch Down: symmetric formula with **(L/S)^(a ± b)**",
        "Power Option: forward price via **moment generating function**",
        "Swaps: discount factor **(1+r)^(−n/freq)** with 30/360 day count",
    ]

    for i, c in enumerate(corrections, 1):
        st.markdown(f"{i}. {c}")

    # ── Architecture ──
    st.markdown("---")
    st.markdown("#### 🏗️ Architecture")

    st.code("""
structured_products_app/
├── main.py                          # Entry point + navigation
├── config.py                        # Shared styles, constants, presets
├── requirements.txt                 # Dependencies
├── models/
│   ├── black_scholes.py             # BSM engine + Greeks + implied vol
│   ├── exotic_options.py            # 15 exotic options (closed-form)
│   ├── monte_carlo.py               # GBM simulation + convergence
│   └── swaps.py                     # IRS cashflow generator
└── pages/
    ├── structured_products.py       # 20-leg payoff analyzer + presets
    ├── swaps_page.py                # Swap schedule + NPV + DV01
    ├── exotic_pricer.py             # 15 exotics + Greeks surface 3D
    ├── monte_carlo_page.py          # MC engine + paths + distribution
    └── roadmap.py                   # This page
    """, language="text")

    st.markdown("---")
    st.caption("Built with Streamlit · Python · NumPy/SciPy · Plotly")
