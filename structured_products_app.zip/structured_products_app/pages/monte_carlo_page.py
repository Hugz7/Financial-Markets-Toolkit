"""
monte_carlo_page.py — Monte Carlo Simulation Engine.
"""

import streamlit as st
import numpy as np
import plotly.graph_objects as go
import pandas as pd
from config import (PLOTLY_LAYOUT, ACCENT_GOLD, ACCENT_BLUE, ACCENT_GREEN,
                    ACCENT_RED, TEXT_GREY)
from models.monte_carlo import (
    simulate_gbm, price_options_mc, terminal_distribution_stats,
    convergence_analysis, sample_paths, histogram_data,
)
from models.black_scholes import call_price


def render():
    st.markdown("## 🎲 Monte Carlo Simulation Engine")
    st.caption("GBM Price Paths · European/Asian/Barrier/Lookback Pricing · "
               "Convergence Analysis · Terminal Distribution")

    # ── Parameters ──
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("#### Simulation Parameters")
        S0 = st.number_input("Spot S₀", value=100.0, step=1.0, key="mc_S")
        K = st.number_input("Strike K", value=100.0, step=1.0, key="mc_K")
        T = st.number_input("Maturity T (yr)", value=1.0, step=0.25, key="mc_T")
        r = st.number_input("Risk-Free Rate r", value=0.05, step=0.005,
                            format="%.3f", key="mc_r")
        sigma = st.number_input("Volatility σ", value=0.20, step=0.01,
                                format="%.2f", key="mc_sig")
        q = st.number_input("Dividend Yield q", value=0.02, step=0.005,
                            format="%.3f", key="mc_q")

    with col2:
        st.markdown("#### Engine Settings")
        n_sims = st.select_slider("Nb Simulations",
                                  options=[1000, 5000, 10000, 25000, 50000, 100000],
                                  value=50000, key="mc_nsims")
        n_steps = st.select_slider("Nb Time Steps",
                                   options=[52, 126, 252, 504],
                                   value=252, key="mc_nsteps")
        H_up = st.number_input("Upper Barrier H", value=120.0, step=5.0, key="mc_H")
        H_down = st.number_input("Lower Barrier L", value=80.0, step=5.0, key="mc_L")
        seed = st.number_input("Random Seed", value=42, step=1, key="mc_seed")

    st.markdown("---")

    # ── Run Simulation ──
    if st.button("🚀 Run Monte Carlo Simulation", type="primary", key="mc_run"):
        with st.spinner(f"Simulating {n_sims:,} paths × {n_steps} steps..."):
            S_paths = simulate_gbm(S0, r, q, sigma, T, n_sims, n_steps, seed)
            st.session_state.mc_paths = S_paths
            st.session_state.mc_params = dict(S0=S0, K=K, T=T, r=r, sigma=sigma,
                                               q=q, H_up=H_up, H_down=H_down)
        st.success(f"Simulation complete: {n_sims:,} paths generated.")

    if "mc_paths" not in st.session_state:
        st.info("Click **Run Monte Carlo Simulation** to generate paths.")
        return

    S_paths = st.session_state.mc_paths
    params = st.session_state.mc_params
    S_T = S_paths[:, -1]

    # ── MC Pricing Results ──
    st.markdown("#### 💰 MC Pricing Results")
    mc_results = price_options_mc(S_paths, params["K"], params["r"], params["T"],
                                  params["H_up"], params["H_down"])

    # Add BSM exact for Euro call/put
    bsm_c = call_price(params["S0"], params["K"], params["T"], params["r"],
                       params["sigma"], params["q"])
    from models.black_scholes import put_price as bsm_put
    bsm_p = bsm_put(params["S0"], params["K"], params["T"], params["r"],
                     params["sigma"], params["q"])
    mc_results[0]["exact"] = bsm_c
    mc_results[0]["error_pct"] = abs(mc_results[0]["price"] - bsm_c) / bsm_c * 100
    mc_results[1]["exact"] = bsm_p
    mc_results[1]["error_pct"] = abs(mc_results[1]["price"] - bsm_p) / bsm_p * 100

    rows = []
    for res in mc_results:
        row = {
            "Option": res["name"],
            "MC Price": f"{res['price']:.4f}",
            "Std Error": f"{res['se']:.6f}",
            "95% CI Low": f"{res['ci_low']:.4f}",
            "95% CI High": f"{res['ci_high']:.4f}",
            "BSM Exact": f"{res['exact']:.4f}" if res["exact"] else "N/A",
            "Error %": f"{res['error_pct']:.2f}%" if res["error_pct"] else "",
            "Status": ("✅" if res["error_pct"] and res["error_pct"] < 5
                       else ("⚠️" if res["error_pct"] else "")),
        }
        rows.append(row)

    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

    # ── Sample Paths Chart ──
    st.markdown("#### 📈 Sample GBM Paths")
    sp = sample_paths(S_paths, n_sample=15)
    n_months = sp.shape[1]
    months = list(range(n_months))

    fig_paths = go.Figure()
    colors = ["#5DADE2", "#2ECC71", "#E74C3C", "#9B59B6", "#F39C12",
              "#1ABC9C", "#E67E22", "#3498DB", "#E91E63", "#00BCD4",
              "#8BC34A", "#FF5722", "#607D8B", "#CDDC39", "#795548"]
    for i in range(sp.shape[0]):
        fig_paths.add_trace(go.Scatter(
            x=months, y=sp[i], name=f"Path {i+1}",
            line=dict(color=colors[i % len(colors)], width=1.5),
            opacity=0.7,
        ))

    fig_paths.add_hline(y=params["S0"], line_dash="dash", line_color=TEXT_GREY)
    if params["H_up"] > params["S0"]:
        fig_paths.add_hline(y=params["H_up"], line_dash="dot",
                            line_color=ACCENT_RED, annotation_text="H_up")
    if params["H_down"] < params["S0"]:
        fig_paths.add_hline(y=params["H_down"], line_dash="dot",
                            line_color=ACCENT_RED, annotation_text="H_down")

    fig_paths.update_layout(
        **PLOTLY_LAYOUT,
        title="Sample GBM Paths (monthly sampling)",
        xaxis_title="Month", yaxis_title="Price",
        height=400, showlegend=False,
    )
    st.plotly_chart(fig_paths, use_container_width=True)

    # ── Terminal Distribution + Convergence ──
    col_dist, col_conv = st.columns(2)

    with col_dist:
        st.markdown("#### 📊 Terminal Distribution S_T")
        hist = histogram_data(S_T, n_bins=30)
        fig_hist = go.Figure()
        fig_hist.add_trace(go.Bar(
            x=[(h["bin_low"] + h["bin_high"]) / 2 for h in hist],
            y=[h["freq"] for h in hist],
            width=[(h["bin_high"] - h["bin_low"]) * 0.9 for h in hist],
            marker_color=ACCENT_BLUE, opacity=0.8,
        ))
        fig_hist.add_vline(x=params["K"], line_dash="dash",
                           line_color=ACCENT_GOLD, annotation_text="K")
        fig_hist.update_layout(
            **PLOTLY_LAYOUT, title="S_T Distribution",
            xaxis_title="S_T", yaxis_title="Frequency %", height=350,
        )
        st.plotly_chart(fig_hist, use_container_width=True)

        # Stats
        stats = terminal_distribution_stats(S_T, params["K"])
        stats_df = pd.DataFrame([
            {"Statistic": k, "Value": f"{v:.4f}" if isinstance(v, float) else str(v)}
            for k, v in stats.items()
        ])
        st.dataframe(stats_df, use_container_width=True, hide_index=True, height=300)

    with col_conv:
        st.markdown("#### 📉 Convergence (European Call)")
        conv = convergence_analysis(S_paths, params["K"], params["r"], params["T"])

        fig_conv = go.Figure()
        n_paths = [c["n_paths"] for c in conv]
        mc_prices = [c["mc_price"] for c in conv]
        se_vals = [c["std_error"] for c in conv]

        fig_conv.add_trace(go.Scatter(
            x=n_paths, y=mc_prices, name="MC Price",
            line=dict(color=ACCENT_GREEN, width=2),
            error_y=dict(type="data", array=[1.96 * s for s in se_vals],
                         visible=True, color=ACCENT_GREEN),
        ))
        fig_conv.add_hline(y=bsm_c, line_dash="dash", line_color=ACCENT_GOLD,
                           annotation_text=f"BSM = {bsm_c:.4f}")
        fig_conv.update_layout(
            **PLOTLY_LAYOUT, title="MC Price Convergence",
            xaxis_title="Number of Paths", yaxis_title="MC Price",
            xaxis_type="log", height=350,
        )
        st.plotly_chart(fig_conv, use_container_width=True)

        conv_df = pd.DataFrame(conv)
        conv_df.columns = ["N Paths", "MC Price", "Std Error"]
        conv_df["Abs Error"] = abs(conv_df["MC Price"] - bsm_c)
        st.dataframe(
            conv_df.style.format({"MC Price": "{:.4f}", "Std Error": "{:.4f}",
                                  "Abs Error": "{:.4f}", "N Paths": "{:,}"}),
            use_container_width=True, hide_index=True,
        )
