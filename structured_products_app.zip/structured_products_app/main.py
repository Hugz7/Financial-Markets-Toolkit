"""
main.py — Structured Products Pricer
Run with: streamlit run main.py
"""

import streamlit as st

# ── Page Config (must be first Streamlit command) ──
st.set_page_config(
    page_title="Structured Products Pricer",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ──
st.markdown("""
<style>
    /* Dark theme overrides */
    .stApp {
        background-color: #0E1117;
    }
    section[data-testid="stSidebar"] {
        background-color: #1B2A4A;
        border-right: 1px solid #2C4A6E;
    }
    section[data-testid="stSidebar"] .stMarkdown h1,
    section[data-testid="stSidebar"] .stMarkdown h2,
    section[data-testid="stSidebar"] .stMarkdown h3 {
        color: #D4A843;
    }
    section[data-testid="stSidebar"] .stMarkdown p,
    section[data-testid="stSidebar"] .stMarkdown li {
        color: #8899AA;
    }
    /* Metric cards */
    [data-testid="stMetricValue"] {
        color: #D4A843;
        font-weight: 700;
    }
    [data-testid="stMetricLabel"] {
        color: #8899AA;
    }
    /* Tables */
    .stDataFrame {
        border: 1px solid #2C4A6E;
        border-radius: 8px;
    }
    /* Buttons */
    .stButton > button[kind="primary"] {
        background-color: #D4A843;
        color: #0E1117;
        border: none;
        font-weight: 700;
    }
    .stButton > button[kind="primary"]:hover {
        background-color: #E8BD5A;
    }
    /* Number inputs */
    .stNumberInput input {
        background-color: #1A3A5C;
        color: #5DADE2;
        border: 1px solid #2C4A6E;
    }
    /* Selectbox */
    .stSelectbox > div > div {
        background-color: #1A3A5C;
        color: #5DADE2;
    }
    /* Expanders */
    .streamlit-expanderHeader {
        background-color: #213555;
        border: 1px solid #2C4A6E;
        border-radius: 6px;
        color: #D4A843;
    }
    /* Hide Streamlit branding */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
</style>
""", unsafe_allow_html=True)

# ── Sidebar Navigation ──
with st.sidebar:
    st.markdown("# 📊 Structured Products")
    st.markdown("##### Pricer & Analyzer  v5")
    st.markdown("---")

    page = st.radio(
        "Navigation",
        [
            "📐 Structured Products",
            "🔄 Swaps",
            "🧮 Exotic Pricer",
            "🎲 Monte Carlo",
            "🗺️ Roadmap",
        ],
        label_visibility="collapsed",
    )

    st.markdown("---")
    st.markdown("#### ⚙️ Quick Info")
    st.markdown(
        "- **20 legs** × 20 instruments\n"
        "- **15 exotic options** (BSM)\n"
        "- **Monte Carlo** engine\n"
        "- **IRS** cashflow analyzer\n"
        "- Full **Greeks** surface"
    )
    st.markdown("---")
    st.caption("Python · Streamlit · NumPy · SciPy · Plotly")

# ── Page Routing ──
if page == "📐 Structured Products":
    from pages.structured_products import render
    render()

elif page == "🔄 Swaps":
    from pages.swaps_page import render
    render()

elif page == "🧮 Exotic Pricer":
    from pages.exotic_pricer import render
    render()

elif page == "🎲 Monte Carlo":
    from pages.monte_carlo_page import render
    render()

elif page == "🗺️ Roadmap":
    from pages.roadmap import render
    render()
